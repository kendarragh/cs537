#include <stdio.h>
void stat(int);
