extern int p = 0;
extern int s = 0;
extern int u = 0;
extern int bigS = 0;
extern int v = 0;
extern int c = 0;
