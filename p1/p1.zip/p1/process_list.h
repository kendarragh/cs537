int* get_proc();
void get_proc_by_pid(int);
