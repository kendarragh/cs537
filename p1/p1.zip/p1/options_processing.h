extern int p; 
extern int pid;
extern int u;
extern int s;
extern int bigS;
extern int v;
extern int c; 
void options(int , char** );
